i = 1

while i != 11:
    print(" " * (10-i) + "##" * i)
    i = i + 1
