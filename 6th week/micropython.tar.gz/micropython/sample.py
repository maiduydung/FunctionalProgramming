i = 1
sum = 0

while i != 11:
    sum = sum + i
    i = i + 1

print("1 + 2 + ... + 10 =")
print(sum)
